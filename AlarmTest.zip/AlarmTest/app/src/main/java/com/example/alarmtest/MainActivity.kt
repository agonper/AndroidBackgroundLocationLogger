package com.example.alarmtest

import android.arch.lifecycle.Observer
import android.arch.lifecycle.ViewModelProviders
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.TextView
import com.example.alarmtest.alarm.OneMinuteAlarm
import com.example.alarmtest.coordinates.CoordinatesProvider
import com.example.alarmtest.coordinates.CoordinatesRepository
import com.example.alarmtest.managers.PermissionsManager
import com.example.alarmtest.managers.PowerManager
import com.example.alarmtest.persistence.AppDatabase
import io.reactivex.disposables.Disposable

class MainActivity : AppCompatActivity() {

    private lateinit var tickText: TextView

    private lateinit var tickRepository: TickRepository
    private lateinit var coordsProvider: CoordinatesProvider
    private lateinit var coordsReposotory: CoordinatesRepository
    private lateinit var model: MainViewModel

    private var coordsSubscription: Disposable? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tickText = findViewById(R.id.tickText)

        AppDatabase.init(this)
        tickRepository = TickRepository(this)
        coordsProvider = CoordinatesProvider(this)
        coordsReposotory = CoordinatesRepository()

        PermissionsManager(this).askLocationAccess()
        PowerManager(this).requestSavingsDeactivation()

        OneMinuteAlarm(this).schedule()

        model = ViewModelProviders.of(this).get(MainViewModel::class.java)

        val coordsCountObserver = Observer<Long> { coordsCount->
            tickText.text = "Coords stored: $coordsCount"
        }

        model.coordsCount.observe(this, coordsCountObserver)
    }

    override fun onResume() {
        super.onResume()
//        displayTicks()
        coordsSubscription = coordsProvider.coords.subscribe { coords ->
            coordsReposotory.save(coords)
        }
    }

    override fun onPause() {
        super.onPause()
        coordsSubscription?.dispose()
    }

    fun resetTicks(view: View) {
        coordsReposotory.deleteAll()
//        tickRepository.clear()
//        displayTicks()
    }

    private fun displayTicks() {
        tickText.text = String.format("Ticks: %d", tickRepository.ticks)
    }
}
