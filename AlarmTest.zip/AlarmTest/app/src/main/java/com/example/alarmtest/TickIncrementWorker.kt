package com.example.alarmtest

import android.content.Context
import android.util.Log
import androidx.work.Worker
import androidx.work.WorkerParameters

class TickIncrementWorker(context: Context, params: WorkerParameters): Worker(context, params) {

    private val TAG = javaClass.canonicalName

    private var tickRepository: TickRepository = TickRepository(context)

    override fun doWork(): Result {
        Log.d(TAG, "Work started")
        tickRepository.increment()
        Log.d(TAG, "Tick incremented")
        return Result.success()
    }
}