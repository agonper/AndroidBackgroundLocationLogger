package com.example.alarmtest.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import androidx.work.OneTimeWorkRequest
import androidx.work.WorkManager
import com.example.alarmtest.TickIncrementWorker

class AlarmReceiver: BroadcastReceiver() {

    private val TAG = javaClass.canonicalName

    override fun onReceive(context: Context?, intent: Intent?) {
        Log.d(TAG, "Alarm triggered")
        context?.let { ctx ->
            OneMinuteAlarm(ctx).reschedule()

            val tickIncrementWork = OneTimeWorkRequest.from(TickIncrementWorker::class.java)
            WorkManager.getInstance().enqueue(tickIncrementWork)

            Log.d(TAG, "Work enqueued")
        }
    }
}