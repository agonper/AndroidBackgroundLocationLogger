package com.example.alarmtest

import android.content.Context
import android.content.SharedPreferences

class TickRepository(context: Context) {

    private val tickKey = "TICK"

    private val sharedPreferences: SharedPreferences = context.getSharedPreferences(
        context.packageName, Context.MODE_PRIVATE
    )

    var ticks: Long
        get() {
            return sharedPreferences.getLong(tickKey, 0)
        }
        private set(tick) {
            sharedPreferences.edit()
                .putLong(tickKey, tick)
                .apply()
        }

    fun increment() {
        ticks++
    }

    fun clear() {
        ticks = 0
    }
}