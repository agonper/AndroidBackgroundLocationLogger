package com.example.alarmtest.coordinates

import android.arch.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface CoordinatesDao {
    @Query("SELECT COUNT(*) FROM coordinates")
    fun count(): LiveData<Long>

    @Insert
    fun save(coords: Coordinates)

    @Query("DELETE FROM coordinates")
    fun deleteAll()
}