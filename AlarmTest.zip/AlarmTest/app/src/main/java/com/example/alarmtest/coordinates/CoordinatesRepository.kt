package com.example.alarmtest.coordinates

import android.arch.lifecycle.LiveData
import com.example.alarmtest.persistence.AppDatabase

class CoordinatesRepository {

    private val coordinatesDao = AppDatabase.db.coordsDao()

    val count: LiveData<Long>
        get() = coordinatesDao.count()

    fun save(coordinates: Coordinates) = coordinatesDao.save(coordinates)

    fun deleteAll() = coordinatesDao.deleteAll()
}