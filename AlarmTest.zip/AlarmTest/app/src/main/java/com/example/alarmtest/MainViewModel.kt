package com.example.alarmtest

import android.arch.lifecycle.LiveData
import android.arch.lifecycle.ViewModel
import com.example.alarmtest.coordinates.CoordinatesRepository

class MainViewModel: ViewModel() {
    private val coordinatesRepository = CoordinatesRepository()

    val coordsCount: LiveData<Long> by lazy {
        coordinatesRepository.count
    }
}